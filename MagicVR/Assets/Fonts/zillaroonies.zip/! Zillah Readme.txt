Zillah Readme!

Thank you for downloading my font...

These fonts were made by me for me.  Because they were created for specific personal tasks, you will
find that there are some characters missing, some characters out of place, and some 
characters you've probably never seen the likes of before!  <<smiles>>

I make no guarantees about how this font will work for you... Use at your own risk... Neither
Zillah nor Moon in Aquarius is responsible for any damages incurred by use of this font.

This font is free... I hope you enjoy it!

Blessings - Zillah

www.mooninaquarius.homestead.com
mooninaquarius@hotmail.com